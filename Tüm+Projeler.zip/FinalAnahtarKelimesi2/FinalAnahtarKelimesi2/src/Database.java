
public final class Database {
    
    public  void baglantiKur(String username,String password) {
        
        
        System.out.println(username);
        System.out.println(password);
        
    }
    
}
