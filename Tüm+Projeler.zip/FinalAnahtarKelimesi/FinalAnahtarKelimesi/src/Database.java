
public class Database {
    public static final  String databaseIsmi = "test";
    public static final String userName = "root";
    public static final String password = "12345";
    
    
}
