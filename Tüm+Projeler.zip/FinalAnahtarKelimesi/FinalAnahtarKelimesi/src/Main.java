
public class Main {
    public static void main(String[] args) {
        /*FinalTest f1 = new FinalTest("Obje1");
        FinalTest f2 = new FinalTest("Obje2");
        
        System.out.println("Obje Sayısı: " + f1.obje_sayisi);
        System.out.println("Obje Sayısı: " + f2.obje_sayisi);*/
        
        //System.out.println(Math.PI);
        
        //Math.PI = 3.15;
        
        
        

        System.out.println("Database İsmi : " + Database.databaseIsmi);
        System.out.println("UserName : " + Database.userName);
        System.out.println("Password : " + Database.password);
        
        Database.userName = "root2";
        
        
    }
    
}
