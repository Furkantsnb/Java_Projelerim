
public class Main {
    
    public static void ucuncufonksiyon() {
        
        int a = 12 / 0;
         
        
    }
    
    public static void ikincifonksiyon() {
       
        ucuncufonksiyon();
        
       
    }
    public static void birincifonksiyon() {
        
        ikincifonksiyon();
        
    }
    public static void main(String[] args) {
        
        birincifonksiyon();
        
        
    }
}
