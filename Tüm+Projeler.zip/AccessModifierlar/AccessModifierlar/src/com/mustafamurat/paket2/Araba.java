
package com.mustafamurat.paket2;

public class Araba {
    String model = "Renault";
    String renk = "Gümüş";
    String yil = "2001";
    
}
