
package com.mustafamurat.paket1;
import com.mustafamurat.paket2.*;


public class At extends Hayvan{
    
    public At(String isim) {
        super(isim);
    }
    public void ismini_soyle() {
        
        System.out.println(super.isim);
        
    }
    
    
}
