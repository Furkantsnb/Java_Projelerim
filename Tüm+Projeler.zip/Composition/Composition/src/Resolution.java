
public class Resolution {
    
    private int en;
    
    private int boy;

    public Resolution(int en, int boy) {
        this.en = en;
        this.boy = boy;
    }

    /**
     * @return the en
     */
    public int getEn() {
        return en;
    }

    /**
     * @param en the en to set
     */
    public void setEn(int en) {
        this.en = en;
    }

    /**
     * @return the boy
     */
    public int getBoy() {
        return boy;
    }

    /**
     * @param boy the boy to set
     */
    public void setBoy(int boy) {
        this.boy = boy;
    }
    
    
    
}
